# openvpn_xorpatch
OpenVPN xor scramble patch

This patch adds obfuscation capability to OpenVPN, allowing it to bypass network traffic sensors which aim to detect usage of the protocol and log, throttle or block it.

This patch is not designed to enhance or replace the existing encryption functions within OpenVPN and thus it should not be used for this purpose.
